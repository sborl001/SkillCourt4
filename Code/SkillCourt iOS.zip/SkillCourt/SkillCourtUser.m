//
//  SkillCourtUser.m
//  SkillCourt
//
//  Created by sebastien dolce on 3/6/16.
//  Copyright © 2016 Gummy. All rights reserved.
//

#import "SkillCourtUser.h"

@implementation SkillCourtUser

// Insert code here to add functionality to your managed object subclass

@end
