//
//  SkillCourtUser+CoreDataProperties.m
//  SkillCourt
//
//  Created by sebastien dolce on 3/6/16.
//  Copyright © 2016 Gummy. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "SkillCourtUser+CoreDataProperties.h"

@implementation SkillCourtUser (CoreDataProperties)

@dynamic firstName;
@dynamic lastName;
@dynamic email;
@dynamic phone;
@dynamic position;
@dynamic username;
@dynamic password;
@dynamic sequences;

@end
