//
//  TeamManagementTableViewCell.m
//  SkillCourt
//
//  Created by sebastien dolce on 2/27/16.
//  Copyright © 2016 Gummy. All rights reserved.
//

#import "TeamManagementTableViewCell.h"

@implementation TeamManagementTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
