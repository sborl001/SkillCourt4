//
//  StepsTableViewCell.m
//  SkillCourt
//
//  Created by sebastien dolce on 4/28/16.
//  Copyright © 2016 Gummy. All rights reserved.
//

#import "StepsTableViewCell.h"

@implementation StepsTableViewCell

- (void)awakeFromNib {
    // Initialization code
    
        
        //self.backgroundColor = [UIColor clearColor];
       // self.backgroundView.backgroundColor = [UIColor clearColor];
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
